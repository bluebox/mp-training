from selenium.webdriver.common.by import By


class LoginPage:
    Hrms_id = (By.NAME,'username')
    generate_otp_btn = (By.XPATH,'//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/button')
    otp1 = (By.XPATH,'//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/div/div[1]/input')
    otp2 = (By.XPATH,'//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/div/div[2]/input')
    otp3 = (By.XPATH, '//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/div/div[3]/input')
    otp4 = (By.XPATH, '//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/div/div[4]/input')
    otp5 = (By.XPATH, '//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/div/div[5]/input')
    otp6 = (By.XPATH, '//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[2]/div/div[6]/input')
    login_btn = (By.XPATH,'//*[@id="app"]/div[2]/div/div[2]/div/div/form/div[3]/button')
    hr_group = (By.XPATH,'//*[@id="app"]/div/div[1]/div[1]/div[2]/ul/li[6]/a')

    def __init__(self,driver):
        self.driver = driver
    def send_hrms_id_element_locator(self):
        return self.driver.find_element(*LoginPage.Hrms_id)

    def send_generate_otp_btn_locator(self):
        return self.driver.find_element(*LoginPage.generate_otp_btn)

    def send_otp_locator1(self):
        return self.driver.find_element(*LoginPage.otp1)
    def send_otp_locator2(self):
        return self.driver.find_element(*LoginPage.otp2)
    def send_otp_locator3(self):
        return self.driver.find_element(*LoginPage.otp3)
    def send_otp_locator4(self):
        return self.driver.find_element(*LoginPage.otp4)
    def send_otp_locator5(self):
        return self.driver.find_element(*LoginPage.otp5)
    def send_otp_locator6(self):
        return self.driver.find_element(*LoginPage.otp6)

    def send_login_btn_locator(self):
        return self.driver.find_element(*LoginPage.login_btn)

    def send_hr_group_btn_locator(self):
        return self.driver.find_element(*LoginPage.hr_group)
