# from select import select
from selenium.webdriver.common.by import By
from selenium.webdriver.support import select
from selenium.webdriver.support.wait import WebDriverWait

from pageobjects.LoginPage import LoginPage
from utilities.BaseClass import BaseClass
import time
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support import select


class TestOne(BaseClass):
    def test_login(self):
        self.driver.maximize_window()
        obj = LoginPage(self.driver)
        obj.send_hrms_id_element_locator().send_keys('MED000849')
        obj.send_generate_otp_btn_locator().click()
        time.sleep(1)
        obj.send_otp_locator1().send_keys(1)
        obj.send_otp_locator2().send_keys(2)
        obj.send_otp_locator3().send_keys(3)
        obj.send_otp_locator4().send_keys(1)
        obj.send_otp_locator5().send_keys(1)
        obj.send_otp_locator6().send_keys(1)
        obj.send_login_btn_locator().click()
        time.sleep(1)
        obj.send_hr_group_btn_locator().click()
        self.driver.find_element(By.XPATH,'//*[@id="app"]/div/div[1]/div[1]/div[2]/ul/li[6]/div/div/div[2]/a[2]').click()
        time.sleep(2)
        self.driver.find_element(By.XPATH,'//*[@id="app"]/div/div[3]/div/div[1]/div[1]/div/div[2]/button').click()
        time.sleep(3)
        # self.driver.find_element(By.NAME,'fromDate').send_keys('2023-06-11')
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[1]/div/div/div/input').setAttribute('value', '2023-06-08')
        # el.get_property('value')
        # el.clear()
        # el.send_keys('2023-06-08')
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[3]/div/div/label[1]/span[2]').click()
        obj11 = self.driver.find_element(By.NAME,'fromDate')
        obj11.click()
        time.sleep(2)
        date_picker = self.driver.find_element(By.CLASS_NAME, "ant-picker-panel")
        date_picker.find_elements(By.XPATH, './div')[0].find_elements(By.XPATH, './div')[1].find_elements(By.XPATH,'./table/tbody/tr[2]/td[6]')[0].click()
        obj11 = self.driver.find_element(By.NAME, 'toDate')
        obj11.click()
        time.sleep(2)
        date_picker = self.driver.find_elements(By.CLASS_NAME, "ant-picker-panel")[1]
        date_picker.find_elements(By.XPATH, './div')[0].find_elements(By.XPATH, './div')[1].find_elements(By.XPATH, './table/tbody/tr[2]/td[6]')[0].click()
        time.sleep(3)
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[4]/div/div').click()
        time.sleep(2)
        dropdown = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, '/html/body/div[5]/div/div/div/div[2]/div[1]/div/div/div[4]'))
        )
        dropdown.click()
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[4]/div/div/div/div').send_keys('Optival')
        time.sleep(2)
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[5]/div/div/div/span[1]')
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[5]/div/div/div').click()
        # ---UU---
        self.driver.find_element(By.XPATH,'/html/body/div[6]/div/div/div/div[2]/div[1]/div/div/div').click()
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[6]/div/textarea').click()
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[6]/div/textarea').send_keys('automated lock')
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock_lockForApplying"]').click()
        self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[2]/button').click()
        time.sleep(3)
        self.driver.refresh()
        time.sleep(5)
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)
        self.driver.find_element(By.XPATH,'//*[@id="app"]/div/div[3]/div/div[1]/div[3]/div/div/div/div/div/div/div/div/table/tbody/tr[3]/td[5]/div/button[4]').click()
        time.sleep(3)
        self.driver.find_element(By.XPATH,'//*[@id="delete_attendance_lock"]/div/div/div/div[2]/div/div[1]/button').click()
        time.sleep(3)

        # div = self.driver.find_element(By.XPATH,'//div[6]/div/div/div/div[2]/div[1]/div/div')
        # div.find_element(By.XPATH,'/div[2]').click()
        # # Select the option by title attribute
        # option = WebDriverWait(self.driver, 10).until(
        #     EC.visibility_of_element_located((By.XPATH, "/html/body/div[6]/div/div/div/div[2]/div[1]/div/div/div[3]"))
        #     # or
        #     # EC.visibility_of_element_located((By.CSS_SELECTOR, "div[title='Option Title']"))
        # )
        # option.click()
        # time.sleep(2)

        # self.driver.find_element(By.NAME,'applicableFor').click()
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'/html/body/div[4]/div/div/div/div[2]/div[1]/div/div/div[3]/div').click()
        # time.sleep(5)
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[5]/div/div').click()
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'/html/body/div[6]/div/div/div/div[2]/div[1]/div/div/div/div').click()
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[6]/div/textarea').send_keys('automated lock')
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock_lockForApplying"]').click()
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[2]/button').click()
        # time.sleep(3)
        # self.driver.refresh()
        # time.sleep(3)
        # self.driver.find_element(By.XPATH,
        #                          '//*[@id="app"]/div/div[3]/div/div[1]/div[1]/div/div[2]/button').click()
        # time.sleep(2)
        # obj11 = self.driver.find_element(By.NAME, 'fromDate')
        # obj11.click()
        # time.sleep(2)
        # date_picker = self.driver.find_element(By.CLASS_NAME, "ant-picker-panel")
        # date_picker.find_elements(By.XPATH, './div')[0].find_elements(By.XPATH, './div')[1].find_elements(By.XPATH,
        #                                                                                                   './table/tbody/tr[2]/td[6]')[
        #     0].click()
        # obj11 = self.driver.find_element(By.NAME, 'toDate')
        # obj11.click()
        # time.sleep(2)
        # date_picker = self.driver.find_elements(By.CLASS_NAME, "ant-picker-panel")[1]
        # date_picker.find_elements(By.XPATH, './div')[0].find_elements(By.XPATH, './div')[1].find_elements(By.XPATH,
        #                                                                                                   './table/tbody/tr[2]/td[6]')[
        #     0].click()
        # time.sleep(3)
        # self.driver.find_element(By.NAME, 'applicableFor').click()
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[3]/div/div/label[2]/span[2]').click()
        # time.sleep(2)
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[4]/div/div/div/div').click()
        # self.driver.find_element(By.XPATH,'/html/body/div[7]/div/div/div/div[2]/div[1]/div/div/div[7]/div').click()
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[5]/div/div/div/div').click()
        # self.driver.find_element(By.XPATH,'/html/body/div[7]/div/div/div/div[2]/div[1]/div/div/div[4]/div').click()
        # self.driver.find_element(By.XPATH,'//*[@id="rc_select_1402"]').click()
        # self.driver.find_element(By.XPATH,'/html/body/div[6]/div/div/div/div[2]/div[1]/div/div/div/div').click()
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[1]/div[7]/div/textarea').send_keys("automated department lock")
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock_lockForApplying"]').click()
        # self.driver.find_element(By.XPATH,'//*[@id="add_attendance_lock"]/div/div/div[2]/form/div[2]/button').click()
        # time.sleep(2)
