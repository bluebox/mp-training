import pytest as pytest
from selenium  import webdriver


@pytest.fixture(scope = 'class')
def setup(request):
    driver = webdriver.Chrome(executable_path = '/home/mphs/Desktop/SELENIUM/chromedriver')
    driver.get('https://hrmstest.medplusindia.com/login')
    driver.implicitly_wait(4)

    request.cls.driver = driver
    yield
    driver.close()


