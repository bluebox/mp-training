package com.lms.web.sheduler;



import com.lms.web.dao.AttendanceDAO;
import com.lms.web.model.Attendance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;

@Component
public class AttendanceScheduler {

	@Autowired
    private AttendanceDAO attendanceDAO;


    @Scheduled(cron = "0 59 23 * * *")
    public void validateDailyAttendance() {
        LocalDate today = LocalDate.now();
        Date sqlDate = Date.valueOf(today);

        List<Integer> allEmployees = attendanceDAO.getAllEmployeeIds();

        for (Integer empId : allEmployees) {
            Attendance att = null;
            try {
                att = attendanceDAO.getAttendanceForDay(empId, sqlDate);
            } catch (Exception e) {
                attendanceDAO.forceMarkAbsent(empId, sqlDate);
                continue;
            }

            if (att.getCheckIn() != null && att.getCheckOut() == null) {
                attendanceDAO.updateStatus(empId, sqlDate, "Absent");
            } 
            else if (att.getCheckIn() != null && att.getCheckOut() != null) {
                Duration duration = Duration.between(
                        att.getCheckIn().toLocalTime(),
                        att.getCheckOut().toLocalTime()
                );

                long hrs = duration.toHours();
                if (hrs >= 8) {
                    attendanceDAO.updateStatus(empId, sqlDate, "Present");
                } else if (hrs >= 4) {
                    attendanceDAO.updateStatus(empId, sqlDate, "Half Day");
                } else {
                    attendanceDAO.updateStatus(empId, sqlDate, "Absent");
                }
            }
        }
        System.out.println("Attendance validation completed for " + today);
    }
}
