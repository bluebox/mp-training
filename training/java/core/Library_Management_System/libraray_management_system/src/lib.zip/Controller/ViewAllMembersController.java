package Controller;

import java.util.List;

import domain.Book;
import domain.Member;
import domain.checking_enum.Availability;
import domain.checking_enum.Status;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import domain.checking_enum.Gender;
public class ViewAllMembersController {
	

	
	
	
	    @FXML
	    public Service.MemberService memberService = new Service.MemberService();
	    

	    public void handleviewallmembers() {
	    	BorderPane root = new BorderPane();
	    	List<Member> list=memberService.getAllMembers();
	    	TableView<Member> table = new TableView<Member>();

	    	TableColumn <Member, String> Member_name= new TableColumn<Member, String>("Membername"); 
	    	Member_name.setCellValueFactory (new PropertyValueFactory<Member, String>("name"));

	    	TableColumn <Member, String> Email = new TableColumn<Member, String>("Memberemail"); 
	    	Email.setCellValueFactory (new PropertyValueFactory<Member, String>("email"));

	    	TableColumn <Member, Integer> Mobile = new TableColumn <Member, Integer>("Mobile");
	    	Mobile.setCellValueFactory(new PropertyValueFactory<Member, Integer>("Mobile"));
	    	TableColumn <Member, String> Address = new TableColumn <Member, String>("Address");
	    	Address.setCellValueFactory(new PropertyValueFactory<Member, String>("Address"));
	    	TableColumn <Member, Gender> Gender = new TableColumn <Member, Gender>("Gender");
	    	Gender.setCellValueFactory(new PropertyValueFactory<Member, Gender>("Gender"));
	    	table.getColumns().add(Member_name);
	    	System.out.println(Member_name.toString());
	    	System.out.println(Email.toString());
	    	table.getColumns().add(Email);

	    	table.getColumns().add(Mobile);
	    	table.getColumns().add(Address);
	    	table.getColumns().add(Gender);
	    	
	    	table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	    	for(Member m:list)
	    	table.getItems().add(m); 
	    	
	    	root.setCenter(table);

	    	Scene scene = new Scene(root, 588, 388);

	    	Stage primaryStage =new Stage();
	    	primaryStage.setTitle("TableView Demo");

	    	primaryStage.setScene(scene);

	    	primaryStage.show();
	    }
}