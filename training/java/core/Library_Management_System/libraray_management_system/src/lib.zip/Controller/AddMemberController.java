package Controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import domain.Member;
import domain.checking_enum.Gender;
import Service.MemberService;

public class AddMemberController {

    @FXML
    public  TextField nameField, emailField, mobileField, addressField;
    @FXML
    public ComboBox<String> genderBox;
   @FXML
    public MemberService memberService;

    public void handleAddMember() {
        try {
            Member member = new Member(
                nameField.getText(),
                emailField.getText(),
                Integer.parseInt(mobileField.getText()),
                
                addressField.getText(),Gender.FEMALE
            );
            MemberService memberService = new MemberService();
            memberService.addMember(member);
            showAlert("Member added successfully.");
        } catch (Exception e) {
        	System.out.println("Error: " + nameField.getText());
        	System.out.println("Error: " + emailField.getText());
        	System.out.println("Error: " +  Integer.parseInt(mobileField.getText()));
        	System.out.println("Error: " + addressField.getText());
            showAlert("Error: " + e.getMessage());
            System.out.println(e.getMessage());
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(msg);
        alert.show();
    }
}
