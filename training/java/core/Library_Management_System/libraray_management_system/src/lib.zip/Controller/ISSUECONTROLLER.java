package Controller;

import DAO.Issue_RecordDAO;
import domain.Issue_records;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.SQLException;
import java.util.List;

public class ISSUECONTROLLER {
    @FXML
    private TableView<Issue_records> issueTable;
    @FXML
    private TableColumn<Issue_records, Integer> bookIdCol;
    @FXML
    private TableColumn<Issue_records, Integer> memberIdCol;
    @FXML
    private TableColumn<Issue_records, domain.checking_enum.Status_issue> statusCol;
    @FXML
    private TableColumn<Issue_records, java.util.Date> issueDateCol;
    @FXML
    private TableColumn<Issue_records, java.util.Date> returnDateCol;

    @FXML
    public void initialize() {
        bookIdCol.setCellValueFactory(new PropertyValueFactory<>("bookid"));
        memberIdCol.setCellValueFactory(new PropertyValueFactory<>("memberid"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status_issue"));
        issueDateCol.setCellValueFactory(new PropertyValueFactory<>("issuedate"));
        returnDateCol.setCellValueFactory(new PropertyValueFactory<>("returndate"));

        try {
            List<Issue_records> records = Issue_RecordDAO.printAllIssueRecords();
            ObservableList<Issue_records> data = FXCollections.observableArrayList(records);
            issueTable.setItems(data);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}