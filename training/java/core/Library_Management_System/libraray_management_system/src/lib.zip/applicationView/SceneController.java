package applicationView;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SceneController {
	private Stage stage;
	private Scene scene;
	private Parent root;
	
public void switchtoscene1(ActionEvent event) throws IOException {
	Parent root= FXMLLoader.load(getClass().getResource("HOme1.fxml"));
	stage=(Stage)((Node)event.getSource()).getScene().getWindow();
	stage.setScene(scene);
	stage.show();
	
	
}


public void switchtoscene2(ActionEvent event) throws IOException {
	Parent root= FXMLLoader.load(getClass().getResource("Home.fxml"));
	stage=(Stage)((Node)event.getSource()).getScene().getWindow();
	stage.setScene(scene);
	stage.show();

}


}
