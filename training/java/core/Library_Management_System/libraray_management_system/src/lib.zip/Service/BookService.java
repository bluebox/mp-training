package Service;



import java.sql.SQLIntegrityConstraintViolationException;

import DAO.Bookdao;
import domain.Book;


public class BookService {

	Bookdao db=new Bookdao();
	public void addbooks(Book book) throws SQLIntegrityConstraintViolationException {
		db.addBooks(book);
		
	}
	public void updateavailability() {
		db.Updatebookavailability(null, null);
		
	}
	public void updatebookdetails() {
		db.updateBookDetails(null);
	}
	public void viewallbooks() {
		db.viewallbooks();
		
	}
}
