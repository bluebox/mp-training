package Service;

import java.util.List;

import DAO.Memberdao;
import domain.Member;

public class MemberService {
	 Memberdao mdao = new Memberdao();

	
	public boolean addMember(Member member) {
		return mdao.addMember(member);
	}
	public boolean updateMember(Member member) {
		return mdao.updateMember(member);
	}
	public List<Member> getAllMembers() {
		return mdao.getAllMembers();
	}
	

}
