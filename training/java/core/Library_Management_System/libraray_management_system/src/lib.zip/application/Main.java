package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage stage) {
        try {
        	//FXMLLoader loader = new FXMLLoader(getClass().getResource("HOme1.fxml"));
        	Parent root= FXMLLoader.load(getClass().getResource("HOme1.fxml"));
          //  AnchorPane root = loader.load();
            
            Scene scene = new Scene(root);
            stage.setTitle("Add Book");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
