package DAO;

import domain.Member;
import domain.checking_enum.Gender;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class Memberdao {
    private static final String URL = "jdbc:mysql://localhost:3306/library_management_system";
    private static final String USER = "devuser";
    private static final String PASSWORD = "Bobby@514"; 

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
        
    }
         
    public boolean addMember(Member member) {
        String sql = "INSERT INTO members (Name, Email, Mobile, Gender, Address) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            stmt.setInt(3, member.getMobile());
            stmt.setString(4,member.getGender().getType());
            stmt.setString(5, member.getAddress());

            int rows = stmt.executeUpdate();
            return rows > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean updateMember(Member member) {
        String sql = "UPDATE members SET Name = ?, Email = ?, Mobile = ?, Gender = ?, Address = ? WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            stmt.setLong(3, member.getMobile());
            stmt.setString(4,member.getGender().getType());
            stmt.setString(5, member.getAddress());
           
            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public List<Member> getAllMembers() {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT Memberid,Name,Email,Mobile,Gender,Address from library_management_system.members";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
        	
        	
            while (rs.next()) {
                Member member = new Member(rs.getString("Name"),rs.getString("Email"),rs.getInt("Mobile"),rs.getString("Address"),Gender.getstatus(rs.getString("gender")));
                

                members.add(member);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return members;
    }
    public static void main(String[] args) {
		System.out.println("this is called");
		Memberdao d = new Memberdao();
		
	//	d.addMember(new Member ("Rohan","reddyrohan@335gmail.com",963258741,"hudcyuvd",Gender.MALE));
		List<Member>harihara=d.getAllMembers();
		harihara.forEach(System.out::println);
		
	}
}