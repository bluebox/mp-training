package domain;

import java.util.*;
public class checking_enum{

public enum Status {
	ACTIVE("A"),INACTIVE("I");

	private String type;

	Status(String type) {
		this.type=type;
		// TODO Auto-generated constructor stub
	}
	private static final Map<String,Status> lookup=new HashMap<>();
	static {
		for(Status s:Status.values()) {
			lookup.put(s.getType(), s);
		}
	}
	public  static Status getstatus(String type) {
		return lookup.get(type);
	}
	
	 public String getType() {
		return this.type=type;

	}


}
public enum Availability{
	AVAILABLE("A"),ISSUED("I");

	private String type;

	Availability(String type) {
		this.type=type;
		// TODO Auto-generated constructor stub
	}
	private static final Map<String,Availability> lookup=new HashMap<>();
	static {
		for(Availability a:Availability.values()) {
			lookup.put(a.getType(), a);
		}
	}
	public static Availability getstatus(String type) {
		return lookup.get(type);
	}
	
	public String getType() {
		return this.type=type;

	}
}
public enum Gender{
	MALE("M"),FEMALE("F");

	private String type;

	Gender(String type) {
		this.type=type;
		// TODO Auto-generated constructor stub
	}
	private static final Map<String,Gender> lookup=new HashMap<>();
	static {
		for(Gender g:Gender.values()) {
			lookup.put(g.getType(), g);
		}
	}
	 public static  Gender getstatus(String type) {
		return lookup.get(type);
	}
	
	 public String getType() {
		return this.type=type;

	}
}
public enum Status_issue{
	ISSUED("I") ,RETURNED("R");

	private String type;

	Status_issue(String type) {
		this.type=type;
		// TODO Auto-generated constructor stub
	}
	private static final Map<String,Status_issue> lookup=new HashMap<>();
	static {
		for(Status_issue i:Status_issue.values()) {
			lookup.put(i.getType(), i);
		}
	}
	public static Status_issue getstatus(String type) {
		return lookup.get(type);
	}
	
	public String getType() {
		return this.type=type;

	}
}
}

