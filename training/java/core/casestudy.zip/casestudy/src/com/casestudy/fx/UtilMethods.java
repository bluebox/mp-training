package com.casestudy.fx;

import javafx.scene.control.Alert;

public class UtilMethods {
	public static  void showAlert(Alert.AlertType type, String title, String message) {
	    Alert alert = new Alert(type);
	    alert.setTitle(title);
	    alert.setHeaderText(null);
	    alert.setContentText(message);
	    alert.showAndWait();
	}

}
