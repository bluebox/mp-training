package com.example.Backend.domain;

import com.example.Backend.constants.BookAvailability;
import com.example.Backend.constants.BookCategory;
import com.example.Backend.constants.BookStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {

	private int bookId;
	private String title;
	private String author;
	private BookCategory category;
	private BookStatus status = BookStatus.ACTIVE;
	private BookAvailability availability = BookAvailability.AVAILABLE;
}
