package com.example.Backend.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Backend.domain.IssueRecord;
import com.example.Backend.serviceImplementation.IssueRecordServiceImplementation;

@RestController
@RequestMapping("/issues")
public class IssueRecordController {

	@Autowired
	private IssueRecordServiceImplementation issueRecordService;

	@PostMapping("/issue")
	public String issueBook(@RequestBody IssueRecord issueRecord) {

		int memberId = issueRecord.getMemberId();
		int bookId = issueRecord.getBookId();
		return issueRecordService.issueBook(bookId, memberId);

	}

	@PostMapping("/return")
	public String returnBook(@RequestBody IssueRecord issueRecord) {

		int memberId = issueRecord.getMemberId();
		int bookId = issueRecord.getBookId();
		return issueRecordService.returnBook(memberId, bookId);
	}

	@GetMapping
	public List<IssueRecord> getAllIssues() {
		return issueRecordService.getAllIssues();
	}

}
