package com.example.Backend.serviceImplementation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Backend.constants.IssueRecordStatus;
import com.example.Backend.dao.IssueRecordDao;
import com.example.Backend.domain.IssueRecord;

@Service
public class IssueRecordServiceImplementation {

	@Autowired
	private IssueRecordDao issueRepo;

	public String issueBook(int bookId, int memberId) {
		IssueRecord issue = new IssueRecord();
		issue.setBookId(bookId);
		issue.setMemberId(memberId);
		issue.setStatus(IssueRecordStatus.ISSUED);
		issue.setIssueDate(LocalDate.now());
		issue.setReturnDate(null);

		issueRepo.issueBook(issue);
		return "Book issued Successfully";

	}

	public String returnBook(int memberId, int bookId) {

		IssueRecord issue = issueRepo.findActiveIssue(memberId, bookId);
		if (issue == null) {
			return "no Active books";
		}

		issueRepo.returnBook(issue.getIssueId(), LocalDate.now());
		return "Book returned successfully";

	}

	public List<IssueRecord> getAllIssues() {
		return issueRepo.getAllIssues();
	}

}
