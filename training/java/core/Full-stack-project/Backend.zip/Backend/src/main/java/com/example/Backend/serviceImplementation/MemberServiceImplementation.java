package com.example.Backend.serviceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Backend.dao.MemberDao;
import com.example.Backend.domain.Member;

@Service
public class MemberServiceImplementation {

	@Autowired
	private MemberDao memberDao;

	public int addMember(Member member) {
		return memberDao.addMember(member);
	}

	public void updateMember(int id, Member member) {
		member.setMemberId(id);
		memberDao.updateMember(member);
	}

	public Member getMemberById(int id) {
		return memberDao.findById(id);
	}

	public List<Member> getAllMembers() {
		return memberDao.findAllMembers();
	}

}
