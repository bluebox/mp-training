package com.example.Backend.serviceImplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Backend.dao.BookDao;
import com.example.Backend.domain.Book;

@Service
public class BookServiceImplementation {

	@Autowired
	private BookDao bookDao;

	public int addBook(Book book) {
		return bookDao.addBook(book);
	}

	public void updateBook(int id, Book book) {
		book.setBookId(id);
		bookDao.updateBook(book);
	}

	public void updateAvailability(int bookId, String availability) {
		bookDao.updateAvailability(bookId, availability);
	}

	public void deleteBook(int bookId) {
		bookDao.deleteBook(bookId);
	}

	public Book getBookById(int id) {
		return bookDao.findById(id);
	}

	public List<Book> getAllBooks() {
		return bookDao.findAllBooks();
	}

	public List<Book> getBooksByMember(int memberId) {
		return bookDao.getBooksByMember(memberId);
	}
}
