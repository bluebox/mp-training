package com.example.Backend.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.example.Backend.constants.BookAvailability;
import com.example.Backend.constants.BookCategory;
import com.example.Backend.constants.BookStatus;
import com.example.Backend.domain.Book;

@Repository
public class BookDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final RowMapper<Book> bookRowMapper = (rs, rowNum) -> {
		Book book = new Book();
		book.setBookId(rs.getInt("book_id"));
		book.setTitle(rs.getString("book_title"));
		book.setAuthor(rs.getString("author"));
		book.setCategory(BookCategory.getEnumConstant(rs.getString("category")));
		book.setStatus(BookStatus.getEnumConstant(rs.getString("status")));
		book.setAvailability(BookAvailability.getEnumConstant(rs.getString("availability")));

		return book;
	};

	public int addBook(Book book) {
		String sql = "insert into books(title,author,category,status,availability) values(?,?,?,?,?)";
		int rows = jdbcTemplate.update(sql, book.getTitle(), book.getAuthor(), book.getCategory().getStringValue(),
				book.getStatus().getStringValue(), book.getAvailability().getStringValue());
		return rows;
	}

	public int updateBook(Book book) {
		booklog(book.getBookId());
		String sql = "update books set title=?, author=?, category=? where book_id=?";
		int rows = jdbcTemplate.update(sql, book.getTitle(), book.getAuthor(), book.getCategory().getStringValue(),
				book.getBookId());
		System.out.println("Rows updated: " + rows);
		return rows;
	}

	public int updateAvailability(int bookId, String availability) {
		String sql = "update books set availability=? where book_id=?";
		int rows = jdbcTemplate.update(sql, availability, bookId);
		System.out.println("Availability updated, rows affected: " + rows);
		return rows;
	}

	public int deleteBook(int id) {
		String sql = "update books set status=? where book_id=?";
		int rows = jdbcTemplate.update(sql, BookStatus.INACTIVE.getStringValue(), id);
		System.out.println("Book deleted (status updated), rows affected: " + rows);
		return rows;
	}

	public List<Book> findAllBooks() {
		String sql = "select * from books where status='A'";
		return jdbcTemplate.query(sql, bookRowMapper);
	}

	public Book findById(int id) {
		String sql = "select * from books where book_id=? and status='A'";
		return jdbcTemplate.queryForObject(sql, bookRowMapper, id);
	}

	public List<Book> getBooksByMember(int memberId) throws DataAccessException {
		String sql = "select b.* from books b join issue_records i on b.book_id=i.book_id where i.member_id=? and i.status='I' and b.status='A'";
		return jdbcTemplate.query(sql, bookRowMapper, memberId);
	}

	public int booklog(int bookId) {
		String sql = "insert into books_log(book_id,title,author,category,availability,status) "
				+ "select book_id,title,author,category,availability,status from books where book_id=?";
		return jdbcTemplate.update(sql, bookId);
	}
}
