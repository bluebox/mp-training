package com.casestudy;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BooksDao {
	
	private Connection conn = DBUtil.getConnection();
	
	public void createBook(Book book) {
		
		String query = "insert into Books (title , author , category , status , availability) values (? , ? , ? , ? , ?)";		
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setString(1, book.getTitle());
		ps.setString(2, book.getAuthor());
		ps.setString(3, book.getCategory());
		ps.setString(4, book.getStatus().getCode()); // handle getStatus() what returns
		ps.setString(5, "A");
		
		int count = ps.executeUpdate();	
		ps.close();
		conn.close();
	}
	
	public void updateBookAvailability(int bookId) throws SQLException {
		
		String query = "select availability from Books where id = ?";
		PreparedStatement ps ;
		ps = conn.prepareStatement(query);
		ps.setInt(1, bookId);
		ResultSet rs = ps.executeQuery();
		
		String availability = "";
		while(rs.next()) {
			availability = rs.getString("availability");
		}
		
		availability =  (availability == "A") ? "I" : "A";
		
		query = "UPDATE Books SET availability = ? WHERE bookId = ?";
		ps = conn.prepareStatement(query);
		ps.setString(1, availability);
		
		int rowsUpdated = ps.executeUpdate();
		
		if(rowsUpdated > 0) {
			System.out.println("book availability modified successfully");
		}
		else {
			System.out.println("book availability modification failed");
		}
		
		//updating in log table also
		query = "UPDATE LogBooks SET availability = ? WHERE bookId = ?";
		ps = conn.prepareStatement(query);
		ps.setString(1, availability);
		
	    rowsUpdated = ps.executeUpdate();
		
		if(rowsUpdated > 0) {
			System.out.println("book availability modified successfully");
			conn.commit();
		}
		else {
			System.out.println("book availability modification failed");
			conn.rollback();
		}
		
		ps.close();
		conn.close();
		
		
	}
	
	public void updateBook(Book book) {
		
		String query = "select title , author , category , status , availability from Books where id = ?";
		PreparedStatement ps ;
		ps = conn.prepareStatement(query);
		ps.setInt(1, book.getId());
		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) {
			
		    int bookId = rs.getInt("id");
		    String title = rs.getString("title");
		    String author = rs.getString("author");
		    String category = rs.getString("category");
		    String status = rs.getString("status");
		    String avaialability = rs.getString("availability")

		    System.out.println("Book ID: " + bookId + ", Title: " + title + ", Author: " + author);
		    query = "insert into LogBooks (id , title , author , category , status , availability) values (? , ? , ? , ? , ? , ?)";
		    ps = conn.prepareStatement(query);
		    int count = ps.executeUpdate();
		    
		}
		
		query = "UPDATE Books SET title = ?, author = ?, category = ?, status = ? WHERE bookId = ?";
		ps = conn.prepareStatement(query);
		ps.setString(1, book.getTitle());
		ps.setString(2, book.getAuthor());
		ps.setString(3, book.getCategory());
		ps.setString(4, book.getStatus().getCode()); // Assuming enum returns "A" or "I"
		ps.setInt(5, book.getBookId());

		int rowsUpdated = ps.executeUpdate();
		
		if (rowsUpdated > 0) {
			conn.commit();
		}
		else {
			conn.rollback();
		}
		
		ps.close();
		conn.close();
	}	
	
	
	public List<Book> viewAllBooks() {
		String query = "select id , title , author , category , status , availability from Books";
		PreparedStatement ps ;
		ps = conn.prepareStatement(query);
		
		ResultSet rs = ps.executeQuery();
		
		List<Book> books = new ArrayList<>();
		
		while (rs.next()) {
			
		    int bookId = rs.getInt("id");
		    String title = rs.getString("title");
		    String author = rs.getString("author");
		    String category = rs.getString("category");
		    String status = rs.getString("status");
		    String avaialability = rs.getString("availability")
		    
		    books.add(new Book(bookId , title , author , category ,Status.fromCode(status)  , Availability.fromCode(avaialability)));		    
		    
		}		
		ps.close();
		conn.close();
		
		return books;
	}
		
		

}
