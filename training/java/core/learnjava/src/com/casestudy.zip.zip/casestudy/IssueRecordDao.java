package com.casestudy;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;

public class IssueRecordDao {
	
	private Connection conn = DBUtil.getConnection();
	
	public void issueBook(IssueRecord issueRecord) throws SQLException {
		
		String sql = "INSERT INTO IssueRecords (bookId, memberId, status, issueDate) VALUES (?, ?, ?, ?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, issueRecord.getBookId());
		ps.setInt(2, issueRecord.getMemberId());
		ps.setString(3, "I"); // Assuming getCode() returns "I" or "R"
		ps.setDate(4, Date.valueOf(issueRecord.getIssueDate()));

		int rowsInserted = ps.executeUpdate();
		
		if (rowsInserted > 0) {
			System.out.println(rowsInserted + " inserted , book issued successfully");
		}
		else {
			System.out.println("book issued failed");
		}
		
		
		// inserting into log table of issue records
		sql = "INSERT INTO LogIssueRecords (bookId, memberId, status, issueDate) VALUES (?, ?, ?, ?)";
		ps = conn.prepareStatement(sql);
		ps.setInt(1, issueRecord.getBookId());
		ps.setInt(2, issueRecord.getMemberId());
		ps.setString(3, "I"); // Assuming getCode() returns "I" or "R"
		ps.setDate(4, Date.valueOf(issueRecord.getIssueDate()));

		rowsInserted = ps.executeUpdate();
		
		if (rowsInserted > 0) {
			System.out.println(rowsInserted + " inserted to log issue records successfully");
			conn.commit();
		}
		else {
			System.out.println("log issue record failed");
			conn.rollback();
		}
		
		ps.close();
		conn.close();
	}
	
	public void returnBook(IssueRecord issueRecord) throws SQLException {
		
		String sql = "Update IssueRecords set status = ?, returnDate = ? where bookId = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1,"R" );
		ps.setDate(2, Date.valueOf(LocalDate.now()));
		ps.setInt(3, issueRecord.getBookId()); 
		

		int rowsInserted = ps.executeUpdate();
		
		if (rowsInserted > 0) {
			System.out.println(rowsInserted + " inserted , book returned successfully");
		}
		else {
			System.out.println("book returned failed");
		}
		
		sql = "insert into LogIssueRecords (status , returnDate)  values (? , ?) where bookId = ?";
		ps = conn.prepareStatement(sql);
		ps.setString(1,"R" );
		ps.setDate(2, Date.valueOf(LocalDate.now()));
		ps.setInt(3, issueRecord.getBookId()); 
		

		rowsInserted = ps.executeUpdate();
		
		if (rowsInserted > 0) {
			System.out.println(rowsInserted + " inserted , book returned successfully");
			conn.commit();
		}
		else {
			System.out.println("book returned failed");
			conn.rollback();
		}
		
		
		
		ps.close();
		conn.close();
	}

}
