package com.casestudy;

public class Book {

	private int bookId;
	private String title;
	private String author;
	private String category;
	private RecordStatus status;
	private Availablity available;

	public Book(Integer bookId, String title, String author, String category, RecordStatus status, Availablity available) {
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.category = category;
		this.status = status;
		this.available = available;
	}

	public Book(String title, String author, String category, RecordStatus status, Availablity available) {
		this.title = title;
		this.author = author;
		this.category = category;
		this.status = status;
		this.available = available;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public RecordStatus getStatus() {
		return status;
	}

	public void setStatus(RecordStatus status) {
		this.status = status;
	}

	public Availablity getAvailable() {
		return available;
	}

	public void setAvailable(Availablity available) {
		this.available = available;
	}

}
