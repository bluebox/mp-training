package com.casestudy;

public enum Availablity {

}
