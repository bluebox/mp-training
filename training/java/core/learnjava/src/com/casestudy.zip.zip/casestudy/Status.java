package com.casestudy;

public enum Status {

}
