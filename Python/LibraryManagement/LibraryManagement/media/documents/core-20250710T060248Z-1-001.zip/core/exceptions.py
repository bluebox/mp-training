
class SmartHomeError(Exception):
    """Base exception for all smart home related errors."""
    pass

class DeviceOfflineError(SmartHomeError):
    """Raised when an action is attempted on a device that is off."""
    pass

class InvalidParameterError(SmartHomeError):
    """Raised when a value passed to a method/setter is out of its valid range or format."""
    pass

class ActionNotSupportedError(SmartHomeError):
    """Raised by perform_action if an action_type is not recognized by a specific device."""
    pass

class AuthenticationError(SmartHomeError):
    """Raised for failed authentication attempts (e.g., wrong passcode)."""
    pass

class PermissionDeniedError(SmartHomeError):
    """Raised if a user tries to perform an action without sufficient permissions."""
    pass
