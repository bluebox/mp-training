
import abc
from abc import ABC, abstractmethod
import asyncio

from ..core.devices import SmartDevice
from ..core.exceptions import DeviceOfflineError, InvalidParameterError, ActionNotSupportedError

class Programmable(ABC):
    """An interface-like class for devices that can be programmed."""
    @abstractmethod
    async def schedule_task(self):
        """Abstract method for scheduling a task asynchronously."""
        pass

class SecuritySensor(SmartDevice):
    """A basic security sensor."""
    def __init__(self, device_id: str):
        super().__init__(device_id)
        self.__is_armed = False

    @property
    def is_armed(self) -> bool:
        return self.__is_armed

    async def arm_sensor(self):
        await asyncio.sleep(0.3) # Simulate arming delay
        if self.is_on:
            if not self.__is_armed:
                self.__is_armed = True
                print(f"Sensor {self._device_id} armed.")
            else:
                print(f"Sensor {self._device_id} is already armed.")
        else:
            raise DeviceOfflineError(f"Cannot arm sensor {self._device_id}. It's off.")

    async def disarm_sensor(self):
        await asyncio.sleep(0.3) # Simulate disarming delay
        if self.is_on:
            if self.__is_armed:
                self.__is_armed = False
                print(f"Sensor {self._device_id} disarmed.")
            else:
                print(f"Sensor {self._device_id} is already disarmed.")
        else:
            raise DeviceOfflineError(f"Cannot disarm sensor {self._device_id}. It's off.")

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        armed_status = "Armed" if self.__is_armed else "Disarmed"
        return f"Security Sensor {self._device_id} is {status}, Status: {armed_status}"

    async def perform_action(self, action_type: str, value=None):
        if action_type == "arm":
            await self.arm_sensor()
        elif action_type == "disarm":
            await self.disarm_sensor()
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SecuritySensor {self._device_id}.")

    def get_supported_actions(self) -> list[str]:
        return ["arm", "disarm"]


class SmartAlarmSystem(SmartDevice, Programmable):
    def __init__(self, device_id: str, siren_volume: int = 5):
        super().__init__(device_id)
        self.__siren_volume = siren_volume # Example additional attribute
        self.__is_armed_status = False

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        alarm_status = "ARMED" if self.__is_armed_status else "DISARMED"
        return f"Alarm System {self._device_id} is {status}, Alarm Status: {alarm_status}, Siren Volume: {self.__siren_volume}"

    async def perform_action(self, action_type: str, value=None):
        if not self.is_on:
            raise DeviceOfflineError(f"Alarm system {self._device_id} is off. Cannot perform action '{action_type}'.")

        if action_type == "arm":
            await asyncio.sleep(0.5) # Simulate arming delay
            if not self.__is_armed_status:
                self.__is_armed_status = True
                print(f"Alarm System {self._device_id} ARMED.")
            else:
                print(f"Alarm System {self._device_id} is already ARMED.")
        elif action_type == "disarm":
            await asyncio.sleep(0.5) # Simulate disarming delay
            if self.__is_armed_status:
                self.__is_armed_status = False
                print(f"Alarm System {self._device_id} DISARMED.")
            else:
                print(f"Alarm System {self._device_id} is already DISARMED.")
        elif action_type == "set_siren_volume":
            await asyncio.sleep(0.2) # Simulate delay
            if isinstance(value, int) and 1 <= value <= 10:
                self.__siren_volume = value
                print(f"Siren volume for {self._device_id} set to {value}.")
            else:
                raise InvalidParameterError(f"Invalid siren volume {value}. Must be an integer between 1 and 10.")
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SmartAlarmSystem {self._device_id}.")

    async def schedule_task(self):
        """Implements the schedule_task from Programmable."""
        await asyncio.sleep(0.1)
        print(f"Alarm System {self._device_id} task scheduled for monitoring.")

    def get_supported_actions(self) -> list[str]:
        return ["arm", "disarm", "set_siren_volume"]
