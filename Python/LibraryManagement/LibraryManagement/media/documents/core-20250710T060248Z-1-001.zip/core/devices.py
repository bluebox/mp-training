
import abc
from abc import ABC, abstractmethod
import asyncio
from datetime import datetime
import re

from ..utils.decorators import log_device_state_change
from ..core.exceptions import DeviceOfflineError, InvalidParameterError, ActionNotSupportedError, AuthenticationError
from ..utils.helpers import validate_device_id # Import the validator

class DeviceRegistrarMeta(abc.ABCMeta):
    """
    Metaclass for SmartDevice to automatically register concrete device subclasses.
    """
    _registered_device_types = {}

    def __new__(mcs, name, bases, namespace):
        cls = super().__new__(mcs, name, bases, namespace)
        # Register only concrete (non-abstract) subclasses of SmartDevice
        if not abc.ABC in bases and name != 'SmartDevice': # Ensure it's a concrete SmartDevice subclass
            mcs._registered_device_types[name] = cls
        return cls

    @classmethod
    def get_registered_device_type(mcs, type_name: str):
        """Allows accessing registered device classes via their string name."""
        return mcs._registered_device_types.get(type_name)


class SmartDevice(ABC, metaclass=DeviceRegistrarMeta):
    _total_devices_created = 0  # Class variable to track total devices

    def __init__(self, device_id: str):
        validate_device_id(device_id) # Validate ID format using regex
        self._device_id = device_id  # Protected attribute
        self.__is_on = False         # Private attribute
        SmartDevice._total_devices_created += 1

    @property
    def is_on(self) -> bool:
        """Public getter for the __is_on attribute."""
        return self.__is_on

    @log_device_state_change
    async def turn_on(self):
        """Turns the device on asynchronously."""
        if not self.__is_on:
            self.__is_on = True
            print(f"Device {self._device_id} turning on...")
            await asyncio.sleep(0.1) # Simulate delay
            print(f"Device {self._device_id} turned on.")
        else:
            print(f"Device {self._device_id} is already on.")

    @log_device_state_change
    async def turn_off(self):
        """Turns the device off asynchronously."""
        if self.__is_on:
            self.__is_on = False
            print(f"Device {self._device_id} turning off...")
            await asyncio.sleep(0.1) # Simulate delay
            print(f"Device {self._device_id} turned off.")
        else:
            print(f"Device {self._device_id} is already off.")

    @abstractmethod
    def get_status_report(self) -> str:
        """Returns a string detailing the device's current state."""
        pass

    @abstractmethod
    async def perform_action(self, action_type: str, value=None):
        """Performs a device-specific action asynchronously."""
        pass

    @abstractmethod
    def get_supported_actions(self) -> list[str]:
        """Returns a list of action types supported by the specific device."""
        pass

    @classmethod
    def get_device_count(cls) -> int:
        """Returns the total number of smart devices created."""
        return cls._total_devices_created

    @staticmethod
    def get_system_time() -> str:
        """Returns the current system time."""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

class SmartLight(SmartDevice):
    def __init__(self, device_id: str):
        super().__init__(device_id)
        self.__brightness = 0  # Private attribute, 0-100

    @property
    def brightness(self) -> int:
        """Public getter for __brightness."""
        return self.__brightness

    @brightness.setter
    def brightness(self, level: int):
        """Public setter for __brightness, with validation."""
        if not self.is_on:
            raise DeviceOfflineError(f"Light {self._device_id} is off. Cannot set brightness.")

        if not isinstance(level, int) or not (0 <= level <= 100):
            raise InvalidParameterError(f"Brightness level {level} for {self._device_id} is out of range (0-100) or not an integer.")

        self.__brightness = level
        print(f"Light {self._device_id} brightness set to {level}.")

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        return f"Light {self._device_id} is {status}, Brightness: {self.__brightness}%"

    async def perform_action(self, action_type: str, value=None):
        await asyncio.sleep(0.2) # Simulate action delay
        if action_type == "set_brightness":
            self.brightness = value # Use the property setter, which includes validation and error handling
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SmartLight {self._device_id}.")

    def get_supported_actions(self) -> list[str]:
        return ["set_brightness"]


class SmartThermostat(SmartDevice):
    def __init__(self, device_id: str):
        super().__init__(device_id)
        self.__temperature = 20.0  # Private attribute, default Celsius

    @property
    def temperature(self) -> float:
        """Public getter for __temperature."""
        return self.__temperature

    @temperature.setter
    def temperature(self, temp: float):
        """Public setter for __temperature, with validation."""
        if not self.is_on:
            raise DeviceOfflineError(f"Thermostat {self._device_id} is off. Cannot set temperature.")

        if not isinstance(temp, (int, float)) or not (18.0 <= temp <= 30.0): # Reasonable range for Celsius
            raise InvalidParameterError(f"Temperature {temp}°C for {self._device_id} is out of range (18.0-30.0) or not a number.")

        self.__temperature = temp
        print(f"Thermostat {self._device_id} temperature set to {temp}°C.")

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        return f"Thermostat {self._device_id} is {status}, Temperature: {self.__temperature}°C"

    async def perform_action(self, action_type: str, value=None):
        await asyncio.sleep(0.3) # Simulate action delay
        if action_type == "set_temperature":
            self.temperature = float(value) # Use the property setter
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SmartThermostat {self._device_id}.")

    def get_supported_actions(self) -> list[str]:
        return ["set_temperature"]


class SmartDoorLock(SmartDevice):
    def __init__(self, device_id: str, passcode: str):
        super().__init__(device_id)
        self.__is_locked = True      # Private attribute
        self.__passcode = str(passcode) # Private attribute, ensure string

    @property
    def is_locked(self) -> bool:
        return self.__is_locked

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        lock_status = "Locked" if self.__is_locked else "Unlocked"
        return f"Door Lock {self._device_id} is {status}, Status: {lock_status}"

    async def perform_action(self, action_type: str, value=None):
        if not self.is_on:
            raise DeviceOfflineError(f"Door Lock {self._device_id} is off. Cannot perform action '{action_type}'.")

        if action_type == "lock":
            await asyncio.sleep(0.4) # Simulate action delay
            if not self.__is_locked:
                self.__is_locked = True
                print(f"Door Lock {self._device_id} locked.")
            else:
                print(f"Door Lock {self._device_id} is already locked.")
        elif action_type == "unlock":
            await asyncio.sleep(0.4) # Simulate action delay
            if value is None or not isinstance(value, str):
                raise InvalidParameterError(f"Unlock action for {self._device_id} requires a string passcode.")
            if value == self.__passcode:
                if self.__is_locked:
                    self.__is_locked = False
                    print(f"Door Lock {self._device_id} unlocked.")
                else:
                    print(f"Door Lock {self._device_id} is already unlocked.")
            else:
                raise AuthenticationError(f"Incorrect passcode for Door Lock {self._device_id}.")
        elif action_type == "set_passcode":
            await asyncio.sleep(0.5) # Simulate action delay
            if not isinstance(value, tuple) or len(value) != 2 or not all(isinstance(p, str) for p in value):
                raise InvalidParameterError(f"Set passcode for {self._device_id} requires a tuple (old_code, new_code).")
            old_code, new_code = value
            from ..utils.helpers import validate_strong_passcode # Import here to avoid circular dependency
            if old_code == self.__passcode:
                validate_strong_passcode(new_code) # Validate new passcode complexity
                self.__passcode = new_code
                print(f"Passcode for Door Lock {self._device_id} updated.")
            else:
                raise AuthenticationError(f"Incorrect old passcode for Door Lock {self._device_id}.")
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SmartDoorLock {self._device_id}.")

    def get_supported_actions(self) -> list[str]:
        return ["lock", "unlock", "set_passcode"]


class SmartCamera(SmartDevice):
    SUPPORTED_RESOLUTIONS = ["720p", "1080p", "4K"]

    def __init__(self, device_id: str):
        super().__init__(device_id)
        self.__is_recording = False  # Private attribute
        self.__resolution = "1080p"  # Private attribute

    @property
    def is_recording(self) -> bool:
        return self.__is_recording

    @property
    def resolution(self) -> str:
        return self.__resolution

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        recording_status = "Recording" if self.__is_recording else "Not Recording"
        return f"Camera {self._device_id} is {status}, Status: {recording_status}, Resolution: {self.__resolution}"

    async def perform_action(self, action_type: str, value=None):
        if not self.is_on:
            raise DeviceOfflineError(f"Camera {self._device_id} is off. Cannot perform action '{action_type}'.")

        if action_type == "start_recording":
            await asyncio.sleep(0.3) # Simulate action delay
            if not self.__is_recording:
                self.__is_recording = True
                print(f"Camera {self._device_id} started recording.")
            else:
                print(f"Camera {self._device_id} is already recording.")
        elif action_type == "stop_recording":
            await asyncio.sleep(0.3) # Simulate action delay
            if self.__is_recording:
                self.__is_recording = False
                print(f"Camera {self._device_id} stopped recording.")
            else:
                print(f"Camera {self._device_id} is not recording.")
        elif action_type == "set_resolution":
            await asyncio.sleep(0.2) # Simulate action delay
            if value is None or not isinstance(value, str) or value not in self.SUPPORTED_RESOLUTIONS:
                raise InvalidParameterError(f"Resolution '{value}' for Camera {self._device_id} is invalid or not supported. Use {self.SUPPORTED_RESOLUTIONS}.")
            self.__resolution = value
            print(f"Camera {self._device_id} resolution set to {value}.")
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SmartCamera {self._device_id}.")

    def get_supported_actions(self) -> list[str]:
        return ["start_recording", "stop_recording", "set_resolution"]


class SmartSpeaker(SmartDevice):
    def __init__(self, device_id: str):
        super().__init__(device_id)
        self.__volume = 50        # Private attribute, 0-100
        self.__current_track = "None" # Private attribute

    @property
    def volume(self) -> int:
        return self.__volume

    @volume.setter
    def volume(self, level: int):
        if not self.is_on:
            raise DeviceOfflineError(f"Speaker {self._device_id} is off. Cannot set volume.")
        if not isinstance(level, int) or not (0 <= level <= 100):
            raise InvalidParameterError(f"Volume level {level} for {self._device_id} is out of range (0-100) or not an integer.")
        self.__volume = level
        print(f"Speaker {self._device_id} volume set to {level}.")

    @property
    def current_track(self) -> str:
        return self.__current_track

    def get_status_report(self) -> str:
        status = "on" if self.is_on else "off"
        return f"Speaker {self._device_id} is {status}, Volume: {self.__volume}%, Playing: {self.__current_track}"

    async def perform_action(self, action_type: str, value=None):
        if not self.is_on:
            raise DeviceOfflineError(f"Speaker {self._device_id} is off. Cannot perform action '{action_type}'.")

        if action_type == "play_music":
            await asyncio.sleep(0.4) # Simulate action delay
            if value is None or not isinstance(value, str):
                raise InvalidParameterError(f"Play music action for {self._device_id} requires a string track name.")
            self.__current_track = value
            print(f"Speaker {self._device_id} is now playing: {value}.")
        elif action_type == "stop_music":
            await asyncio.sleep(0.3) # Simulate action delay
            if self.__current_track != "None":
                self.__current_track = "None"
                print(f"Speaker {self._device_id} stopped music.")
            else:
                print(f"Speaker {self._device_id} is not playing anything.")
        elif action_type == "set_volume":
            await asyncio.sleep(0.2) # Simulate action delay
            self.volume = value # Use the property setter
        else:
            raise ActionNotSupportedError(f"Action '{action_type}' not supported by SmartSpeaker {self._device_id}.")

    def get_supported_actions(self) -> list[str]:
        return ["play_music", "stop_music", "set_volume"]
